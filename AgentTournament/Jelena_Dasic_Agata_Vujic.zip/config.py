HEIGHT = 24 #24
WIDTH = 32 #32
TICK_RATE = 0.01 #0.01

ASCII_TILES = {"empty": " ", "wall": "#", "blue_agent": "b", "red_agent": "r", "blue_agent_f": "B", "red_agent_f": "R", "blue_flag": "{", "red_flag": "}", "bullet": ".", "unknown": "/"}
